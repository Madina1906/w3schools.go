from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Avg, Max
from .models import Student, Test, TestResult
from .serializers import StudentSerializer, TestSerializer, TestResultSerializer
from rest_framework.decorators import api_view
from django.shortcuts import get_object_or_404

@api_view(['post'])
def create_student(request):
    serializer = StudentSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['get'])
def get_student(request, pk):
    student = get_object_or_404(Student, id=pk)
    serializer = StudentSerializer(student)
    return Response(serializer.data)

@api_view(['get'])
def get_all_students(request):
    students = Student.objects.all()
    serializer = StudentSerializer(students, many=True)
    return Response(serializer.data)

@api_view(['delete'])
def delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    student.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['get'])
def get_results_by_student(request, student_id):
    results = TestResult.objects.filter(student_id=student_id)
    serializer = TestResultSerializer(results, many=True)
    return Response(serializer.data)

@api_view(['get'])
def get_results_by_test(request, test_id):
    results = TestResult.objects.filter(test_id=test_id)
    serializer = TestResultSerializer(results, many=True)
    return Response(serializer.data)

@api_view(['get'])
def get_average_score(request, test_id):
    average_score = TestResult.objects.filter(test_id=test_id).aggregate(Avg('score'))['score__avg']
    return Response({'average_score': average_score}, status=status.HTTP_200_OK)

@api_view(['get'])
def get_highest_score(request, test_id):
    highest_score = TestResult.objects.filter(test_id=test_id).aggregate(Max('score'))['score__max']
    return Response({'highest_score': highest_score}, status=status.HTTP_200_OK)

@api_view(['POST'])
def submit_test_result(request):
    serializer = TestResultSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_all_tests(request):
    tests = Test.objects.all()
    serializer = TestSerializer(tests, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def get_test(request, test_id):
    test = get_object_or_404(Test, id=test_id)
    serializer = TestSerializer(test)
    return Response(serializer.data)

@api_view(['POST'])
def create_test(request):
    serializer = TestSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
