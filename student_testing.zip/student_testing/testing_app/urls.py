from django.urls import path
from .views import *

urlpatterns = [
    path('', get_all_students),
    path('students/post/', create_student),
    path('students/get/<int:pk>/', get_student),
    path('students/delete/<int:student_id>/', delete_student),
    path('tests/', get_all_tests),
    path('create_test/', create_test),
    path('results/', submit_test_result),
    path('results/student/<int:student_id>/', get_results_by_student),
    path('results/test/<int:test_id>/', get_results_by_test),
    path('results/test/<int:test_id>/average/', get_average_score),
    path('results/test/<int:test_id>/highest/', get_highest_score),
]

